package phamthiyen.example.lab7_nc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;

public class Bai1 extends AppCompatActivity {
    Button btnRotation,btnMoving,btnZoom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai1);
        btnRotation = findViewById(R.id.btnRotation);
        btnMoving = findViewById(R.id.btnMoving);
        btnZoom = findViewById(R.id.btnZoom);

        btnZoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.anim1);
                btnZoom.startAnimation(animation);
            }
        });
    }
}