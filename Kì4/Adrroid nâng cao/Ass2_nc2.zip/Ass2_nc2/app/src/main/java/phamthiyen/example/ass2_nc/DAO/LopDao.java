package phamthiyen.example.ass2_nc.DAO;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import phamthiyen.example.ass2_nc.DTO.Lop;
import phamthiyen.example.ass2_nc.DbHelper.DbHelper;


public class LopDao {
    SQLiteDatabase db;

    public LopDao(Context context) {
        DbHelper dbHelper = new DbHelper(context);
        db = dbHelper.getWritableDatabase();
    }
    public long insertLop(Lop obj){
        ContentValues values = new ContentValues();
        values.put("tenLop", obj.getTenLop());
        return db.insert("Lop", null, values);
    }
    public int updateLop(Lop obj){
        ContentValues values = new ContentValues();
        values.put("tenLop", obj.getTenLop());
        return db.update("Lop", values, "maLop=?", new String[]{ obj.getMaLop() +""});
    }
    public int deleteLop(int maLop){
        return db.delete("Lop", "maLop=?", new String[]{ maLop +""});
    }
    public List<Lop> getAll(){
        String sql = "select * from Lop";
        return getData(sql);
    }
    public Lop getID(String maLop){
        String sql = "select * from Lop where maLop=?";
        List<Lop> list = getData(sql, maLop);
        return list.get(0);
    }

    @SuppressLint("Range")
    private List<Lop> getData(String sql, String...args) {
        List<Lop> list = new ArrayList<>();
        Cursor c = db.rawQuery(sql, args);
        while (c.moveToNext()){
            Lop obj = new Lop();
            obj.setMaLop( c.getInt( c.getColumnIndex("maLop")));
            obj.setTenLop( c.getString( c.getColumnIndex("tenLop")));
            list.add(obj);
        }
        return list;
    }
}
