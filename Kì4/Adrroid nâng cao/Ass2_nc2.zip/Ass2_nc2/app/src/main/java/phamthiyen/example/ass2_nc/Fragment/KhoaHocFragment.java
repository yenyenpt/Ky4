package phamthiyen.example.ass2_nc.Fragment;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import phamthiyen.example.ass2_nc.DAO.KhoaHocDao;
import phamthiyen.example.ass2_nc.DTO.KhoaHoc;
import phamthiyen.example.ass2_nc.R;
import phamthiyen.example.ass2_nc.adapter.KhoaHocAdapter;


public class KhoaHocFragment extends Fragment {
    ListView lv;
    TextView tvmaKH;
    EditText edTenKH, edSoGioHoc;
    Button btnThem, btnHuy;
    FloatingActionButton fab;

    KhoaHocDao dao;
    KhoaHocAdapter adapter;
    KhoaHoc obj;
    ArrayList<KhoaHoc> list;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_khoa_hoc, null, false);
        lv = view.findViewById(R.id.lvKH);
        fab = view.findViewById(R.id.fabKH);

        dao = new KhoaHocDao(getContext());
        capNhatLv();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog(getContext(), 0);
            }
        });
        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                obj = list.get(i);
                openDialog(getContext(), 1);
                return false;
            }
        });
        return view;
    }

    protected void openDialog(final Context context, final int type){
        Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.dialog_khoa_hoc);

        tvmaKH = dialog.findViewById(R.id.tvMaKhoaHoc);
        edTenKH = dialog.findViewById(R.id.edTenKH);
        edSoGioHoc = dialog.findViewById(R.id.edSoGioHoc);
        btnThem = dialog.findViewById(R.id.btnThemKH);
        btnHuy = dialog.findViewById(R.id.btnHuyKH);

        if (type!=0){
            tvmaKH.setText(String.valueOf(obj.getMaKH()));
            edTenKH.setText(obj.getTenKH());
            edSoGioHoc.setText(obj.getSoGioHoc());
        }

        btnHuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obj = new KhoaHoc();
                obj.setTenKH(edTenKH.getText().toString());
                obj.setSoGioHoc(edSoGioHoc.getText().toString());
                if (validate() >0){
                    if (type ==0){
                        if (dao.insertKH(obj) >0){
                            Toast.makeText(context, "Thêm thành công", Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(context, "Thêm không thành công", Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        obj.setMaKH( Integer.parseInt(tvmaKH.getText().toString()) );
                        if (dao.updateKH(obj) >0){
                            Toast.makeText(context, "Sửa thành công", Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(context, "Sửa không thành công", Toast.LENGTH_SHORT).show();
                        }
                    }
                    capNhatLv();
                    dialog.dismiss();
                }
            }
        });
        dialog.show();
    }
    public void xoa(final int maKH){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Delete");
        builder.setMessage("Bạn có chắc chắn muốn xóa?");
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (dao.deleteKH(maKH) >0){
                    capNhatLv();
                    Toast.makeText(getContext(), "Xóa thành công", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(getContext(), "Xóa không thành công", Toast.LENGTH_SHORT).show();

                }
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private int validate() {
        int check = 1;
        if (edTenKH.getText().length() ==0 || edSoGioHoc.getText().length() ==0){
            Toast.makeText(getContext(), "Bạn phải nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            check = -1;
        }
        try {
            obj.setSoGioHoc( Integer.parseInt( edSoGioHoc.getText().toString() ) +"");
        }catch (Exception e){
            Toast.makeText(getContext(), "Số giờ học phải là số", Toast.LENGTH_SHORT).show();
            check = -1;
        }
        return check;
    }
    public void capNhatLv(){
        list = (ArrayList<KhoaHoc>) dao.getAll();
        adapter = new KhoaHocAdapter(getContext(), this, list);
        lv.setAdapter(adapter);
    }
}
