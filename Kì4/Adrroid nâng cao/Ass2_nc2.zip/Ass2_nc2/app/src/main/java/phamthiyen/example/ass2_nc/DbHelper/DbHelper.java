package phamthiyen.example.ass2_nc.DbHelper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {
    public static final String dbName = "HoTroHocTap";
    public static final int dbVersion = 1;

    public DbHelper(@Nullable Context context) {
        super(context, dbName, null, dbVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sinhVien = "create table SinhVien(" +
                            "maSV integer primary key autoincrement," +
                            "tenSV text not null," +
                            "maKH integer not null references KhoaHoc(maKH)," +
                            "maLop integer not null references Lop(maLop)," +
                            "namSinh text not null)";
        db.execSQL(sinhVien);

        String lop ="create table Lop(" +
                    "maLop integer primary key autoincrement," +
                    "tenLop text not null)";
        db.execSQL(lop);

        String khoaHoc = "create table KhoaHoc(" +
                        " maKH integer primary key autoincrement," +
                        " tenKH text not null," +
                        " soGioHoc text not null)";
        db.execSQL(khoaHoc);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
