package phamthiyen.example.ass2_nc;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import phamthiyen.example.ass2_nc.adapter.GridViewAdapter;

public class MainActivity extends AppCompatActivity {
    GridView gridView;
    Toolbar toolbar;
    ActionBar actionBar;
    GridViewAdapter gridViewAdapter;

    String[] name = {"Course", "Maps", "News", "Social"};
    int[] img = { R.drawable.img_course,
            R.drawable.img_map,
            R.drawable.img_new,
            R.drawable.img_social};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gridView = findViewById(R.id.gridView);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        if (actionBar != null) {
            actionBar.setHomeAsUpIndicator(R.drawable.ic_home);
        }
        if (actionBar != null) {
            actionBar.setTitle("Hỗ trợ học tập");
        }

        gridViewAdapter = new GridViewAdapter(getApplicationContext(), img, name);
        gridView.setAdapter(gridViewAdapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0:
                        Intent intent = new Intent(MainActivity.this, Course.class);
                        startActivity(intent);
                        break;
                    case 1:
                        Intent intent1 = new Intent(MainActivity.this, MapsActivity.class);
                        startActivity(intent1);
                        break;
                    case 2:
                        Intent intent2 = new Intent(MainActivity.this, News.class);
                        startActivity(intent2);
                        break;
                    case 3:
                        Intent intent3 = new Intent(MainActivity.this, Social.class);
                        startActivity(intent3);
                        break;
                    case 4:
                        break;
                }
            }
        });
    }
}