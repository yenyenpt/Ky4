package phamthiyen.example.ass2_nc.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

import phamthiyen.example.ass2_nc.DTO.KhoaHoc;
import phamthiyen.example.ass2_nc.Fragment.KhoaHocFragment;
import phamthiyen.example.ass2_nc.R;


public class KhoaHocAdapter extends ArrayAdapter<KhoaHoc> {
    private final Context context;
    private final ArrayList<KhoaHoc> list;
    private final KhoaHocFragment fragment;
    private ImageView imgXoa;

    public KhoaHocAdapter(@NonNull Context context, KhoaHocFragment fragment, ArrayList<KhoaHoc> list) {
        super(context, 0, list);
        this.context = context;
        this.fragment = fragment;
        this.list = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_khoa_hoc, null );
        KhoaHoc obj = list.get(position);
        TextView tvMaKH = view.findViewById(R.id.tvMaKH);
        TextView tvTenKH = view.findViewById(R.id.tvTenKH);
        TextView tvSoGioHoc = view.findViewById(R.id.tvSoGioHoc);
        imgXoa = view.findViewById(R.id.imgXoaKH);

        tvMaKH.setText("Mã khóa học: "+ obj.getMaKH());
        tvTenKH.setText("Tên khóa học: "+obj.getTenKH());
        tvSoGioHoc.setText("Số giờ học: "+obj.getSoGioHoc());
        imgXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragment.xoa( obj.getMaKH() );
            }
        });
        return view;
    }
}
