package phamthiyen.example.ass2_nc.DAO;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import phamthiyen.example.ass2_nc.DTO.KhoaHoc;
import phamthiyen.example.ass2_nc.DbHelper.DbHelper;


public class KhoaHocDao {
    SQLiteDatabase db;

    public KhoaHocDao(Context context) {
        DbHelper dbHelper = new DbHelper(context);
        db = dbHelper.getWritableDatabase();
    }
    public long insertKH(KhoaHoc obj){
        ContentValues values = new ContentValues();
        values.put("tenKH", obj.getTenKH());
        values.put("soGioHoc", obj.getSoGioHoc());
        return db.insert("KhoaHoc", null, values);
    }
    public int updateKH(KhoaHoc obj){
        ContentValues values = new ContentValues();
        values.put("tenKH", obj.getTenKH());
        values.put("soGioHoc", obj.getSoGioHoc());
        return db.update("KhoaHoc", values, "maKH=?", new String[]{ obj.getMaKH() +""});
    }
    public int deleteKH(int maKH){
        return db.delete("KhoaHoc", "maKH=?", new String[]{ maKH+""});
    }
    public List<KhoaHoc> getAll(){
        String sql = "select * from KhoaHoc";
        return getData(sql);
    }

    public KhoaHoc getID(String maKH){
        String sql = "select * from KhoaHoc where maKH=?";
        List<KhoaHoc> list = getData(sql, maKH);
        return list.get(0);
    }

    @SuppressLint("Range")
    private List<KhoaHoc> getData(String sql, String...args) {
        List<KhoaHoc> list = new ArrayList<>();
        Cursor c = db.rawQuery(sql, args);
        while (c.moveToNext()){
            KhoaHoc obj = new KhoaHoc();
            obj.setMaKH( c.getInt( c.getColumnIndex("maKH")));
            obj.setTenKH( c.getString( c.getColumnIndex("tenKH")));
            obj.setSoGioHoc( c.getString( c.getColumnIndex("soGioHoc")));
            list.add(obj);
        }
        return list;
    }
}
