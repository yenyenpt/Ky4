package phamthiyen.example.ass2_nc.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import phamthiyen.example.ass2_nc.R;


public class GridViewAdapter extends BaseAdapter {
    private final Context context;
    private final int[] img;
    private final String[] name;

    public GridViewAdapter(Context context, int[] img, String[] name) {
        this.context = context;
        this.img = img;
        this.name = name;
    }

    @Override
    public int getCount() {
        return name.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.item_grid_view, null);
        ImageView imgIcon = view.findViewById(R.id.img_icon);
        TextView tvName = view.findViewById(R.id.tvName);

        imgIcon.setImageResource(img[i]);
        tvName.setText(name[i]);
        return view;
    }
}
