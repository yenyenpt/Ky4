package phamthiyen.example.ass2_nc.DTO;

public class SinhVien {
    private int maSV;
    private String tenSV;
    private int maKH;
    private int maLop;
    private String namSinh;

    public SinhVien() {
    }

    public SinhVien(int maSV, String tenSV, int maKH, int maLop, String namSinh) {
        this.maSV = maSV;
        this.tenSV = tenSV;
        this.maKH = maKH;
        this.maLop = maLop;
        this.namSinh = namSinh;
    }

    public int getMaSV() {
        return maSV;
    }

    public void setMaSV(int maSV) {
        this.maSV = maSV;
    }

    public String getTenSV() {
        return tenSV;
    }

    public void setTenSV(String tenSV) {
        this.tenSV = tenSV;
    }

    public int getMaKH() {
        return maKH;
    }

    public void setMaKH(int maKH) {
        this.maKH = maKH;
    }

    public int getMaLop() {
        return maLop;
    }

    public void setMaLop(int maLop) {
        this.maLop = maLop;
    }

    public String getNamSinh() {
        return namSinh;
    }

    public void setNamSinh(String namSinh) {
        this.namSinh = namSinh;
    }
}
