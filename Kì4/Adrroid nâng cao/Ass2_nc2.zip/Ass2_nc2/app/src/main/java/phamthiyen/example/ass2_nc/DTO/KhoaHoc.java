package phamthiyen.example.ass2_nc.DTO;

public class KhoaHoc {
    private int maKH;
    private String tenKH;
    private String soGioHoc;

    public KhoaHoc() {
    }

    public KhoaHoc(int maKH, String tenKH, String soGioHoc) {
        this.maKH = maKH;
        this.tenKH = tenKH;
        this.soGioHoc = soGioHoc;
    }

    public int getMaKH() {
        return maKH;
    }

    public void setMaKH(int maKH) {
        this.maKH = maKH;
    }

    public String getTenKH() {
        return tenKH;
    }

    public void setTenKH(String tenKH) {
        this.tenKH = tenKH;
    }

    public String getSoGioHoc() {
        return soGioHoc;
    }

    public void setSoGioHoc(String soGioHoc) {
        this.soGioHoc = soGioHoc;
    }
}
