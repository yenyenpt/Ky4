package phamthiyen.example.ass2_nc.DAO;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import phamthiyen.example.ass2_nc.DTO.SinhVien;
import phamthiyen.example.ass2_nc.DbHelper.DbHelper;


public class SinhVienDao {
    SQLiteDatabase db;

    public SinhVienDao(Context context) {
        DbHelper dbHelper = new DbHelper(context);
        db = dbHelper.getWritableDatabase();
    }
    public long insertSV(SinhVien obj){
        ContentValues values = new ContentValues();
        values.put("tenSV", obj.getTenSV());
        values.put("maLop", obj.getMaLop());
        values.put("maKH", obj.getMaKH());
        values.put("namSinh", obj.getNamSinh());
        return db.insert("SinhVien", null, values);
    }
    public int updateSV(SinhVien obj){
        ContentValues values = new ContentValues();
        values.put("tenSV", obj.getTenSV());
        values.put("maLop", obj.getMaLop());
        values.put("maKH", obj.getMaKH());
        values.put("namSinh", obj.getNamSinh());
        return db.update("SinhVien", values, "maSV=?", new String[]{ obj.getMaSV() +""});
    }
    public int deleteSV(int maSV){
        return db.delete("SinhVien", "maSV=?", new String[]{ maSV +""});
    }
    public List<SinhVien> getAll(){
        String sql = "select * from SinhVien";
        return getData(sql);
    }

    @SuppressLint("Range")
    private List<SinhVien> getData(String sql, String...args) {
        List<SinhVien> list = new ArrayList<>();
        Cursor c = db.rawQuery(sql, args);
        while (c.moveToNext()){
            SinhVien obj = new SinhVien();
            obj.setMaSV( c.getInt( c.getColumnIndex("maSV")));
            obj.setTenSV( c.getString( c.getColumnIndex("tenSV")));
            obj.setMaLop( c.getInt( c.getColumnIndex("maLop")));
            obj.setMaKH( c.getInt( c.getColumnIndex("maKH")));
            obj.setNamSinh( c.getString( c.getColumnIndex("namSinh")));
            list.add(obj);
        }
        return list;
    }
}
