package phamthiyen.example.ass2_nc.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

import phamthiyen.example.ass2_nc.DAO.KhoaHocDao;
import phamthiyen.example.ass2_nc.DAO.LopDao;
import phamthiyen.example.ass2_nc.DTO.KhoaHoc;
import phamthiyen.example.ass2_nc.DTO.Lop;
import phamthiyen.example.ass2_nc.DTO.SinhVien;
import phamthiyen.example.ass2_nc.Fragment.SinhVienFragment;
import phamthiyen.example.ass2_nc.R;


public class SinhVienAdapter extends ArrayAdapter<SinhVien> {
    private final Context context;
    private final ArrayList<SinhVien> list;
    private final SinhVienFragment fragment;
    private ImageView imgXoa;

    public SinhVienAdapter(@NonNull Context context, SinhVienFragment fragment, ArrayList<SinhVien> list) {
        super(context, 0, list);
        this.context = context;
        this.fragment = fragment;
        this.list = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_student, null );
        SinhVien obj = list.get(position);

        TextView tvMaSV = view.findViewById(R.id.tvMaSV);
        TextView tvTenSV = view.findViewById(R.id.tvTenSV);
        TextView tvLop = view.findViewById(R.id.tvLopSV);
        TextView tvKH = view.findViewById(R.id.tvKhoaHocSV);
        TextView tvNamSinh = view.findViewById(R.id.tvNamSinh);
        imgXoa = view.findViewById(R.id.imgXoaSV);

        tvMaSV.setText("Mã sinh viên: "+obj.getMaSV());
        tvTenSV.setText("Tên sinh viên: "+obj.getTenSV());

        KhoaHocDao khoaHocDao = new KhoaHocDao(context);
        KhoaHoc khoaHoc = khoaHocDao.getID(obj.getMaKH()+"");
        tvKH.setText("Khóa học: "+ khoaHoc.getTenKH());

        LopDao lopDao = new LopDao(context);
        Lop lop = lopDao.getID(obj.getMaLop() +"");
        tvLop.setText("Lớp: "+ lop.getTenLop() );

        tvNamSinh.setText("Năm sinh: "+obj.getNamSinh());
        imgXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragment.xoa( obj.getMaSV() );
            }
        });
        return view;
    }
}
