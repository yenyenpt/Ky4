package phamthiyen.example.ass2_nc.Fragment;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import phamthiyen.example.ass2_nc.DAO.KhoaHocDao;
import phamthiyen.example.ass2_nc.DAO.LopDao;
import phamthiyen.example.ass2_nc.DAO.SinhVienDao;
import phamthiyen.example.ass2_nc.DTO.KhoaHoc;
import phamthiyen.example.ass2_nc.DTO.Lop;
import phamthiyen.example.ass2_nc.DTO.SinhVien;
import phamthiyen.example.ass2_nc.R;
import phamthiyen.example.ass2_nc.adapter.SinhVienAdapter;
import phamthiyen.example.ass2_nc.adapter.SpinnerKH;
import phamthiyen.example.ass2_nc.adapter.SpinnerLop;


public class SinhVienFragment extends Fragment {
    ListView lv;
    SinhVienDao dao;
    ArrayList<SinhVien> list;
    SinhVien obj;
    SinhVienAdapter adapter;
    TextView tvMaSV;
    EditText edTenSV, edNamSinh;

    ArrayList<Lop> listLop;
    LopDao lopDao;
    SpinnerLop spinnerLop;

    ArrayList<KhoaHoc> listKH;
    KhoaHocDao khoaHocDao;
    SpinnerKH spinnerKH;

    int maKH, maLop;
    int positionMaLop, positionMaKH;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_student, null, false);
        lv = view.findViewById(R.id.lvStudent);
        FloatingActionButton fab = view.findViewById(R.id.fabStudent);
        dao = new SinhVienDao(getContext());
        capNhatLV();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog(getActivity(), 0);
            }
        });

        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                obj = list.get(position);
                openDialog(getActivity(), 1);
                return false;
            }
        });
        return view;
    }

    protected void openDialog(final Context context, final int type){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_sinh_vien, null);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

        tvMaSV = view.findViewById(R.id.tvMaSV);
        edTenSV = view.findViewById(R.id.edTenSV);
        edNamSinh = view.findViewById(R.id.edNamSinh);
        Spinner spnKH = view.findViewById(R.id.spnKH);
        Spinner spnLop = view.findViewById(R.id.spnLop);
        Button btnLuu = view.findViewById(R.id.btnThemSV);
        Button btnHuy = view.findViewById(R.id.btnHuySV);

        //lay ma lop
        lopDao = new LopDao(getContext());
        listLop = new ArrayList<>();
        listLop = (ArrayList<Lop>) lopDao.getAll();
        spinnerLop = new SpinnerLop(getContext(), listLop);
        spnLop.setAdapter(spinnerLop);
        spnLop.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                maLop = listLop.get(i).getMaLop();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //lay maKH
        khoaHocDao = new KhoaHocDao(getContext());
        listKH = new ArrayList<>();
        listKH = (ArrayList<KhoaHoc>) khoaHocDao.getAll();
        spinnerKH = new SpinnerKH(getContext(), listKH);
        spnKH.setAdapter(spinnerKH);
        spnKH.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                maKH = listKH.get(i).getMaKH();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        if (type !=0){
            tvMaSV.setText(String.valueOf(obj.getMaSV()));
            edTenSV.setText(obj.getTenSV());
            edNamSinh.setText(obj.getNamSinh());

            for (int i=0; i< listLop.size(); i++){
                if (obj.getMaLop() == listLop.get(i).getMaLop()){
                    positionMaLop =i;
                }
            }
            spnLop.setSelection(positionMaLop);

            for (int i=0; i< listKH.size(); i++){
                if (obj.getMaKH() == listKH.get(i).getMaKH()){
                    positionMaKH =i;
                }
            }
            spnKH.setSelection(positionMaKH);
        }
        btnHuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });

        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validate() >0){
                    obj = new SinhVien();
                    obj.setMaKH(maKH);
                    obj.setMaLop(maLop);
                    obj.setTenSV(edTenSV.getText().toString());
                    obj.setNamSinh(edNamSinh.getText().toString());

                    if (type ==0){
                        if (dao.insertSV(obj) >0){
                            Toast.makeText(getContext(), "Thêm thành công", Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(getContext(), "Thêm không thành công", Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        obj.setMaSV( Integer.parseInt(tvMaSV.getText().toString()));
                        if (dao.updateSV(obj) >0){
                            Toast.makeText(getContext(), "Sửa thành công", Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(getContext(), "Sửa không thành công", Toast.LENGTH_SHORT).show();
                        }
                    }
                    capNhatLV();
                    alertDialog.dismiss();
                }
            }
        });

    }
    public void xoa(final int maLop){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Delete");
        builder.setMessage("Bạn có chắc chắn muốn xóa?");
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (dao.deleteSV(maLop) >0){
                    capNhatLV();
                    Toast.makeText(getContext(), "Xóa thành công", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(getContext(), "Xóa không thành công", Toast.LENGTH_SHORT).show();

                }
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
    public int validate(){
        int check = 1;
        if (edTenSV.getText().length() == 0 || edNamSinh.getText().length() == 0){
            Toast.makeText(getContext(), "Bạn phải nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            check =-1;
        }
        try {
            Integer.parseInt(edNamSinh.getText().toString());
        }catch (Exception e){
            Toast.makeText(getContext(), "Năm sinh phải là số", Toast.LENGTH_SHORT).show();
            check = -1;
        }
        return check;
    }

    private void capNhatLV() {
        list = (ArrayList<SinhVien>) dao.getAll();
        adapter = new SinhVienAdapter(getContext(), this, list);
        lv.setAdapter(adapter);
    }
}
