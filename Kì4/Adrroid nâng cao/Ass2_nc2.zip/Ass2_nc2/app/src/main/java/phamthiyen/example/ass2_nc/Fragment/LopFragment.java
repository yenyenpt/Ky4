package phamthiyen.example.ass2_nc.Fragment;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;


import phamthiyen.example.ass2_nc.DAO.LopDao;
import phamthiyen.example.ass2_nc.DTO.Lop;
import phamthiyen.example.ass2_nc.R;
import phamthiyen.example.ass2_nc.adapter.LopAdapter;

public class LopFragment extends Fragment {
    ListView lv;
    TextView tvmaLop;
    EditText edTenLop;
    Button btnThem, btnHuy;
    FloatingActionButton fab;

    LopDao dao;
    LopAdapter adapter;
    Lop obj;
    ArrayList<Lop> list;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lop, null, false);
        lv = view.findViewById(R.id.lvLop);
        fab = view.findViewById(R.id.fabLop);

        dao = new LopDao(getContext());
        capNhatLv();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog(getContext(), 0);
            }
        });
        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                obj = list.get(i);
                openDialog(getContext(), 1);
                return false;
            }
        });
        return view;
    }

    protected void openDialog(final Context context, final int type){
        Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.dialog_lop);

        tvmaLop = dialog.findViewById(R.id.tvMaLopHoc);
        edTenLop = dialog.findViewById(R.id.edTenLop);
        btnThem = dialog.findViewById(R.id.btnThemLop);
        btnHuy = dialog.findViewById(R.id.btnHuyLop);

        if (type!=0){
            tvmaLop.setText(String.valueOf(obj.getMaLop()));
            edTenLop.setText(obj.getTenLop());
        }

        btnHuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obj = new Lop();
                obj.setTenLop(edTenLop.getText().toString());
                if (validate() >0){
                    if (type ==0){
                        if (dao.insertLop(obj) >0){
                            Toast.makeText(context, "Thêm thành công", Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(context, "Thêm không thành công", Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        obj.setMaLop( Integer.parseInt(tvmaLop.getText().toString()) );
                        if (dao.updateLop(obj) >0){
                            Toast.makeText(context, "Sửa thành công", Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(context, "Sửa không thành công", Toast.LENGTH_SHORT).show();
                        }
                    }
                    capNhatLv();
                    dialog.dismiss();
                }
            }
        });
        dialog.show();
    }
    public void xoa(final int maLop){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Delete");
        builder.setMessage("Bạn có chắc chắn muốn xóa?");
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (dao.deleteLop(maLop) >0){
                    capNhatLv();
                    Toast.makeText(getContext(), "Xóa thành công", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(getContext(), "Xóa không thành công", Toast.LENGTH_SHORT).show();

                }
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private int validate() {
        int check = 1;
        if (edTenLop.getText().length() ==0 ){
            Toast.makeText(getContext(), "Bạn phải nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            check = -1;
        }
        return check;
    }
    public void capNhatLv(){
        list = (ArrayList<Lop>) dao.getAll();
        adapter = new LopAdapter(getContext(), this, list);
        lv.setAdapter(adapter);
    }
}
