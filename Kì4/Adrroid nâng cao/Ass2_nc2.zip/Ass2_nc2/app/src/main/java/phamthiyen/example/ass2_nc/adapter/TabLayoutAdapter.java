package phamthiyen.example.ass2_nc.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import phamthiyen.example.ass2_nc.Fragment.KhoaHocFragment;
import phamthiyen.example.ass2_nc.Fragment.LopFragment;
import phamthiyen.example.ass2_nc.Fragment.SinhVienFragment;


public class TabLayoutAdapter extends FragmentStateAdapter {
    public TabLayoutAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position){
            case 0:
                return new SinhVienFragment();
            case 1:
                return new LopFragment();
            case 2:
                return new KhoaHocFragment();
            default:
                return new SinhVienFragment();
        }

    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
