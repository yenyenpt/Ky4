package com.example.myapplication.demo7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.example.myapplication.R;


public class Demo75MainActivity extends AppCompatActivity {
    ImageView imgGio,imgPhut,imgGiay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo75_main);
        imgGio=findViewById(R.id.demo75ImgHour);
        imgPhut=findViewById(R.id.demo75ImgMinute);
        imgGiay=findViewById(R.id.demo75ImgSecond);
        startRun();
    }
    void startRun()
    {
        Animation animGio= AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.anim_demo75_gio);
        imgGio.startAnimation(animGio);
        Animation animPhut= AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.anim_demo75_phut);
        imgPhut.startAnimation(animPhut);
        Animation animGiay= AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.anim_demo75_giay);
        imgGiay.startAnimation(animGiay);
    }
}