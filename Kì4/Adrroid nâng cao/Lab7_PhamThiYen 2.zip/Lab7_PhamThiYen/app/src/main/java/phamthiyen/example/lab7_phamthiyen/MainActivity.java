package phamthiyen.example.lab7_phamthiyen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView img_all;
    Button btn_zoom, btn_ratate, btn_translate, btn_fade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img_all = findViewById(R.id.img_all);
        btn_zoom = findViewById(R.id.btn_zoom);
        btn_ratate = findViewById(R.id.btn_rotate);
        btn_translate = findViewById(R.id.btn_translate);

        btn_zoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom);
                img_all.startAnimation(animation);
            }
        });
        btn_ratate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
                img_all.startAnimation(animation);
            }
        });
        btn_translate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.translate);
                img_all.startAnimation(animation);
            }
        });
    }
}