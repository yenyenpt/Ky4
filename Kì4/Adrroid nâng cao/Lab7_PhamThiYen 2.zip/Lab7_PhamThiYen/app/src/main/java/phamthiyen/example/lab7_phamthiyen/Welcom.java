package phamthiyen.example.lab7_phamthiyen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Welcom extends AppCompatActivity {
    Button btn_b1, btn_b2, btn_b3;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcom);
        btn_b1 = findViewById(R.id.btn_bai1);
        btn_b2 = findViewById(R.id.btn_bai2);
        btn_b3 = findViewById(R.id.btn_bai3);
        btn_b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(Welcom.this, MainActivity.class);
                startActivity(intent);
            }
        });
        btn_b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(Welcom.this, Bai2.class);
                startActivity(intent);
            }
        });
        btn_b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(Welcom.this, Bai3.class);
                startActivity(intent);
            }
        });
    }
}