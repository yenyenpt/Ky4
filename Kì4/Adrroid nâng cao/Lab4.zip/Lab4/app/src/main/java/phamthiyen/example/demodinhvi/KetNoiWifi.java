package phamthiyen.example.demodinhvi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.net.ConnectException;

public class KetNoiWifi extends AppCompatActivity {
    LocationManager locationManager;
    TextView txtInfo;
    ConnectivityManager connectivityManager;
    NetworkInfo myWifi, my4G;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ket_noi_wifi);
        txtInfo = findViewById(R.id.txtInfo);
        //1: goi service
        connectivityManager= (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        //2: lay thong tin
        myWifi= connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        my4G= connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        //3: Kiem tra xem ai ket noi
        if(myWifi.isAvailable()&& myWifi.isConnected()){
            txtInfo.setText("Ban dang dung"+ myWifi.getTypeName());
        }
        if(my4G.isAvailable()&& my4G.isConnected()){
            txtInfo.setText("Ban dang dung"+ my4G.getTypeName());
        }

    }
    public boolean xinQuyenNguoiDung(){
        if(Build.VERSION.SDK_INT >= 23){
            if(checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                return true; // nhan duoc quyen
            }else{
                ActivityCompat.requestPermissions(KetNoiWifi.this,new String[]{Manifest.permission.READ_CONTACTS},1);
                return  false;
            }
        }else{
            Log.d("TAG","Quyen duoc nhan");
            return true;
        }
    }
}