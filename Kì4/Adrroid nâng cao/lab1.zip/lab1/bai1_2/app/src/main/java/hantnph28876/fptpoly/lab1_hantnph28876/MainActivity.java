package hantnph28876.fptpoly.lab1_hantnph28876;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnKhoiTao, btnDung;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnKhoiTao = findViewById(R.id.btnKhoiTao);
        btnDung = findViewById(R.id.btnDung);
        Intent intent = new Intent(this, MyService1.class);

        btnKhoiTao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putInt("id", 1);
                bundle.putString("hoTen", "Hà");
                bundle.putString("lop", "CP18103");
                intent.putExtra("student", bundle); //gắn bundle vào intent
                startService(intent);
            }
        });

        btnDung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopService(intent);
            }
        });
    }
}