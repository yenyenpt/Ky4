package hantnph28876.fptpoly.bai3;

import android.app.IntentService;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyService extends IntentService {
    int count = 0;
    String check="";

    public MyService() {
        super("MyService");
    }


    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        char c= intent.getCharExtra("char", '0');
        check = intent.getStringExtra("check");
        count = demKyTu(check, c);
    }

    @Override
    public void onDestroy() {
        Toast.makeText(this, "Số ký tự "+check+" là: "+count, Toast.LENGTH_SHORT).show();

        super.onDestroy();
    }
    public int demKyTu(String str, char c){
        int dem = 0;
        for (int i=0; i<str.length(); i++){
            if(str.charAt(i) == c){
                dem++;
            }
        }
        return dem;
    }
}
