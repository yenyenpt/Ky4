package phamthiyen.example.lab1_bai3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText edNhap, edKyTu;
    Button btnTim;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edNhap = findViewById(R.id.edNhap);
        edKyTu = findViewById(R.id.edKyTu);
        btnTim = findViewById(R.id.btnTim);

        Intent intent = new Intent(this, MyService.class);
        btnTim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String str = edNhap.getText().toString();
                char[] c= str.toCharArray();
                intent.putExtra("char", c[0]);

                String check = edKyTu.getText().toString();
                intent.putExtra("check", check);

                startService(intent);
            }
        });
    }
}