package phamthiyen.example.lab2.Lab21;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import phamthiyen.example.lab2.R;

public class Lab2_1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab21);
    }
}