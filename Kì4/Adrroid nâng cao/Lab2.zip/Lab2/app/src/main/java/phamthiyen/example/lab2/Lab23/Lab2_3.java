package phamthiyen.example.lab2.Lab23;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import phamthiyen.example.lab2.R;

public class Lab2_3 extends AppCompatActivity {
    TextView txtNhap;
    Button btn3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab23);
        txtNhap= findViewById(R.id.txtNhap);
        btn3 = findViewById(R.id.btn3);

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str = txtNhap.getText().toString();
                Intent intent = new Intent(Lab2_3.this,Mybr3.class);
                intent.putExtra("Name",str);
                sendBroadcast(intent);

            }
        });

    }
}