package phamthiyen.example.lab7_phamthiyen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class Bai3 extends AppCompatActivity {
    ImageView hourImg;
    ImageView minuteImg;
    ImageView secondImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai3);
        hourImg = findViewById(R.id.imageView752);
        minuteImg = findViewById(R.id.imageView753);
        secondImg = findViewById(R.id.imageView754);
        startClock();
    }

    public void startClock() {
        Animation secondAni =
                AnimationUtils.loadAnimation(getApplicationContext(), R.anim.demo754_animation_second);
        secondImg.startAnimation(secondAni);

        Animation minuteAni =
                AnimationUtils.loadAnimation(getApplicationContext(), R.anim.demo753_animation_minute);
        minuteImg.startAnimation(minuteAni);

        Animation hourAni =
                AnimationUtils.loadAnimation(getApplicationContext(), R.anim.demo752_animation_hour);
        hourImg.startAnimation(hourAni);

    }
}