package phamthiyen.example.lab7_phamthiyen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class Bai2 extends AppCompatActivity {
    Button btn_all, btn_doremon, btn_nobita;
    ImageView imgall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai2);
        imgall = findViewById(R.id.img_all_b2);
        btn_all = findViewById(R.id.btn_all_b2);
        btn_nobita = findViewById(R.id.btn_nobita_b2);
        btn_doremon = findViewById(R.id.btn_doremon);
        btn_all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgall.setImageResource(R.drawable.all);
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slideshow);
                imgall.startAnimation(animation);
            }
        });
        btn_nobita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgall.setImageResource(R.drawable.nobita);
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slideshow);
                imgall.startAnimation(animation);
            }
        });
        btn_doremon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgall.setImageResource(R.drawable.doraemon);
                Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slideshow);
                imgall.startAnimation(animation);
            }
        });
    }
}