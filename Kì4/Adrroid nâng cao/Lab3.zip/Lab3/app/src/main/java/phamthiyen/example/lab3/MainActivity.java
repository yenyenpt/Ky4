package phamthiyen.example.lab3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.lv);
        xinQuyenNguoiDung();
        getContact();

    }
    public boolean xinQuyenNguoiDung(){
        if(Build.VERSION.SDK_INT >= 23){
            if(checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED){
                return true; // nhan duoc quyen
            }else{
                ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.READ_CONTACTS},1);
                return  false;
            }
        }else{
            Log.d("TAG","Quyen duoc nhan");
            return true;
        }
    }
    @SuppressLint("Range")
    void getContact(){
        Uri uri = Uri.parse("content://com.android.contacts/contacts"); // duong dan
        //luu het qua doc
        ArrayList list = new ArrayList();

        //Tao con tro doc du lieu
        Cursor c = getContentResolver().query(uri, null,null,null,null);
        //Neu danh ba co du lieu

        if(c.getCount() > 0){
            //Di chuyen con tro ve ban ghi dau tien
            c.moveToFirst();
            while (!c.isAfterLast()){
                @SuppressLint("Range") String soThuTu = c.getString(c.getColumnIndex(ContactsContract.Contacts._ID));
                @SuppressLint("Range") String ten = c.getString(c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                // Khai bao con tro cot
                Cursor cNumber = getContentResolver().query( ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        new String[]{ ContactsContract.CommonDataKinds.Phone.NUMBER},
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" =? AND "+
                                ContactsContract.CommonDataKinds.Phone.TYPE+" = "+
                                ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE, new String[]{ soThuTu}, null);
                String contactNumber = "";
                // Di chuyen con tro cot ve cot dau tien
                if(cNumber.moveToFirst()){
                    contactNumber = cNumber.getString(cNumber.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                }

                // DOng con tro cot
                cNumber.close();
                //Ket qua
                String kq = soThuTu+ "-" +ten+ "-" + contactNumber;
                list.add(kq);
                c.moveToNext(); // chuyen con tro sang ban ghi tiep theo

            }
            // Dua du lieu len ListView
            ArrayAdapter<String> adapter = new ArrayAdapter<>(context,android.R.layout.simple_list_item_1,list);
            listView.setAdapter(adapter);
        }

    }
}