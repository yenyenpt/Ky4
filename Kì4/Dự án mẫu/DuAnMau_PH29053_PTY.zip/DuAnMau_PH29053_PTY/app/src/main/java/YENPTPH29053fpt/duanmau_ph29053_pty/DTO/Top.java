package YENPTPH29053fpt.duanmau_ph29053_pty.DTO;

public class Top {
    public String tenSach;
    public int soLuong;
}
